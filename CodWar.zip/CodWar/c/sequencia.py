l = int(input())
nums = list( map(int, input().split()))

max_length = 1

i = 0
max_length = 1
while(i < (l -1)):
    current = nums[i]
    next = nums[i + 1]

    if current == 0:
        break
    
    current = current / abs(current)
    next = next / abs(next)
    
  
    
    if current != next:
        max_length += 1
        
    i += 1
        
print(max_length)