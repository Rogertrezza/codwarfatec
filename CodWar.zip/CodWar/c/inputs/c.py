cod, qnt = map(int, input().split())

# Código Descrição Preço Unitário (R$)
# 1 Cachorro-quente R$ 4.00
# 2 X-Salada R$ 4.50
# 3 X-Bacon R$ 5.00
# 4 Torrada simples R$ 2.00
# 5 Refrigerante R$ 1.50

map = {
    1 : 4.00,
    2 : 4.50,
    3 : 5.00,
    4 : 2.00,
    5 : 1.50
}

print("Total: R$ %.2f" % (map[cod] * qnt))