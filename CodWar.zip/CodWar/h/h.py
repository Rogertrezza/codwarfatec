c = int(input())

while(c != 0):
    print(c * 80)
    
    c = int(input())