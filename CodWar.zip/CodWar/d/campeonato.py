num = int(input())

times = []

def find(timeTest):
    for time in times:
        if timeTest == time[0]:
            return time
        
    return None
 
while(num > 0):
    num -= 1
    
    line = input().split()

    time1Name = line[0]
    time1Gols = int(line[2])
    score1 = 0
    
    existing1 = find(time1Name)
    if existing1 != None:
        times.remove(existing1)
        score1 =existing1[1]
    
    time2Name = line[1]
    time2Gols = int(line[3])
    score2 = 0

    existing2 = find(time2Name)
    if existing2 != None:
        times.remove(existing2)
        score2 = existing2[1]
    
    if time1Gols > time2Gols:
        score1 += 3
    elif time2Gols > time1Gols:
        score2 += 3
    else:
        score2 += 1
        score1 += 1
    
    times.append((time1Name, score1))
    times.append((time2Name, score2))


sor = sorted(times, reverse=True)

ajusted = [
]
for i in range(0, len(sor)):
    for j in range(0, len(sor)):
        if i == j:
            continue
        
        if sor[i][1] == sor[j][1]:
            ajusted.append(sor[i])
            ajusted.append(sor[j])
            
    if len(ajusted) > 0:
        ajusted = sorted(ajusted)
        ajusted.pop()
    else:
        e = sor[i]
        ajusted.append()      