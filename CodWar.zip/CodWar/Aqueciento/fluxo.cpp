#include <iostream>
#include <string>

int main()
{
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int qntTestes;
    std::cin >> qntTestes;

    while (qntTestes > 0)
    {
        qntTestes--;

        std::string casoTeste;
        std::cin >> casoTeste;

        bool alavanca1, alavanca2, alavanca3;
        alavanca1 = alavanca2 = alavanca3 = false;
        
        for (const auto entrada : casoTeste)
        {
            if (entrada == 'A')
            {
                if (alavanca1)
                {
                    if (alavanca2)
                    {
                        std::cout << "E";
                    }
                    else
                    {
                        std::cout << "D";
                    }

                    alavanca2 = !alavanca2;
                }
                else
                {
                    std::cout << "D";
                }

                alavanca1 = !alavanca1;
            }
            else if (entrada == 'B')
            {
                if (alavanca2)
                {
                    std::cout << 'E';
                }
                else
                {
                    std::cout << 'D';
                }

                alavanca2 = !alavanca2;
            }
            else if (entrada == 'C')
            {
                if (alavanca3)
                {
                    std::cout << 'E';
                }
                else
                {
                    if (alavanca2)
                    {
                        std::cout << 'E';
                    }
                    else
                    {
                        std::cout << 'D';
                    }

                    alavanca2 = !alavanca2;
                }

                alavanca3 = !alavanca3;
            }
        }
        std::cout << '\n';
    }
}