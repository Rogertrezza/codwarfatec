def main():
    cara = 0
    coroa = 0
    try:
        while True: 
            moeda = str(input())
            if moeda == 'cara':
                cara += 1
            else:
                coroa += 1
    except:
        pass
        if cara > coroa:
            print(cara)
        else:
            print(coroa)
        
    
if __name__ == "__main__":
    main()