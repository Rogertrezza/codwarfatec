def main():
    num1 = int(input())
    l1 = "V"
    l2 = "V"
    l3 = "V"
    quant_alavanca = []
    for i in range(num1):
        alavanca = input()
        quant_alavanca.append(list(alavanca))
    for j in quant_alavanca:
        l1 = "V"
        l2 = "V"
        l3 = "V"
        for i in range(len(j)):
            if j[i] == 'A':
                if l1 == 'V':
                    j[i] = 'D'
                    l1 = 'F'
                else:
                    if l2 == 'V':
                        j[i] = 'D'
                        l2 = 'F'
                    else:
                        j[i] = 'E'
                        l2 = 'V'
            elif j[i] == 'B':
                if l2 == 'V':
                    j[i] = 'D'
                    l2 = 'F'
                else:
                    j[i] = 'E'
                    l2 = 'D'
            elif j[i] == 'C':
                if l3 == 'F':
                    j[i] = 'E'
                    l3 = 'V'
                else:
                    if l2 == 'V':
                        j[i] = 'D'
                        l2 = 'F'
                    else:
                        j[i] = 'E'
                        l2 = 'V'
            
    for saida in quant_alavanca:
        print(saida)
        
if __name__ == "__main__":
    main()