teste = ['A','T']
teste[0] = 'B'

print(teste)