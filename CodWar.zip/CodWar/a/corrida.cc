#include <iostream>
#include <vector>

void setup_fast_io()
{
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
}

int main()
{
    setup_fast_io();

    int num;

    std::vector<char> results;

    while ((std::cin >> num))
    {
        int max = 0;

        for (int i = 0; i < num; i++)
        {
            int curr;
            std::cin >> curr;

            if (curr > max)
            {
                max = curr;
            }
        }

        if (max < 10)
        {
            results.push_back('1');
        }
        else if (max >= 10 && max < 20)
        {
            results.push_back('2');
        }
        else
        {
            results.push_back('3');
        }
    }

    int size = results.size();

    for (int i = 0; i < size; i++)
    {
        std::cout << results[i];

        if (i != size - 1)
        {
            std::cout << '\n';
        }
    }

    return 0;
}