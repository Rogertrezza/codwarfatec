s = int(input())

m = {}
nums = []
count = 11
while(True):
    try:
        nums.append(int(input()))
    except:
        break
    
    count -= 1
    if (count == 0):
        break
    

for i in range(0, len(nums)):
    diff = s - nums[i]
    
    existing = m.get(diff)
    print(existing)
    if existing != None:
        continue
    
    try:
        m[diff] = i

    except:
        m[diff] = None
        pass
    
pairs = []
for key in m:
    index = m.get(key)
    
    try:
        pairIndex = nums.index(key)
        
        v1 = nums[pairIndex]
        v2 = nums[index]
        
        if v2 
        
        pairs.append((v2, v1))
    except:
        continue
    
for pair in pairs:
    x,y = pair
    
    if x + y == s:
        print(f"{x} {y}")